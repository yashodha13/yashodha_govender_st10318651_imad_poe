package com.yashodha.mycalculator
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StatisticsActivity : AppCompatActivity() {

    private lateinit var numberEditText: EditText
    private lateinit var addButton: Button
    private lateinit var storedNumbersTextView: TextView
    private lateinit var clearButton: Button
    private lateinit var averageButton: Button
    private lateinit var minMaxButton: Button
    private lateinit var answerTextView: TextView


    private val numbersArray = Array(10) { 0.0 }
    private var currentNumberIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        numberEditText = findViewById(R.id.numberEditText)
        addButton = findViewById(R.id.addButton)
        storedNumbersTextView = findViewById(R.id.storedNumbersTextView)
        clearButton = findViewById(R.id.clearButton)
        averageButton = findViewById(R.id.averageButton)
        minMaxButton = findViewById(R.id.minMaxButton)
        answerTextView = findViewById(R.id.answerTextView)


        // Retrieve data from intent
        // val receivedNumbersArray = intent.getDoubleArrayExtra("numbersArray") ?: doubleArrayOf()
        // val receivedCurrentNumberIndex = intent.getIntExtra("currentNumberIndex", 0)
// Use the received data
        // System.arraycopy(receivedNumbersArray, 0, numbersArray, 0, receivedCurrentNumberIndex)
        // currentNumberIndex = receivedCurrentNumberIndex

        // Set up click listeners
        addButton.setOnClickListener { addNumber() }
        clearButton.setOnClickListener { clearNumbers() }
        averageButton.setOnClickListener { calculateAverage() }
        minMaxButton.setOnClickListener { findMinMax() }
    }

    // Add entered number to the array
    private fun addNumber() {
        if (currentNumberIndex < numbersArray.size) {
            val enteredNumber = numberEditText.text.toString().toDouble()
            numbersArray[currentNumberIndex] = enteredNumber
            currentNumberIndex++

            // Update the displayed numbers
            displayStoredNumbers()
        }
    }

    // Display the numbers entered so far
    private fun displayStoredNumbers() {
        val stringBuilder = StringBuilder()
        for (i in 0 until currentNumberIndex) {
            stringBuilder.append(numbersArray[i])
            if (i < currentNumberIndex - 1) {
                stringBuilder.append(", ")
            }
        }
        storedNumbersTextView.text = "Numbers entered: $stringBuilder"
    }

    // Clear the array and reset UI
    private fun clearNumbers() {
        for (i in 0 until numbersArray.size) {
            numbersArray[i] = 0.0
        }
        currentNumberIndex = 0

        // Update UI
        storedNumbersTextView.text = ""
        answerTextView.text = ""
    }

    // Calculate and display the average
    private fun calculateAverage() {
        val sum = numbersArray.take(currentNumberIndex).sum()
        val average = if (currentNumberIndex > 0) sum / currentNumberIndex else 0.0
        answerTextView.text = "Average: $average"
    }

    // Find and display the min and max
    private fun findMinMax() {
        val min = numbersArray.take(currentNumberIndex).minOrNull()
        val max = numbersArray.take(currentNumberIndex).maxOrNull()

        answerTextView.text = "Min: $min, Max: $max"
    }
}
